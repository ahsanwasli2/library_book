from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime
import uuid


class CreateBook(BaseModel):
    
    title: str
    author_name: str
    published_date: date


class BooksOut(BaseModel):

    id: Optional[uuid.UUID]
    title: str
    author_name: str
    published_date: date
    created_at: datetime
    class Config:
        orm_mode= True 

class GetOneBook(BaseModel):

    id: Optional[uuid.UUID]



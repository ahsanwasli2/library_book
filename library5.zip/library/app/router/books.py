from fastapi import APIRouter, Depends, status
from ..database import get_db
from sqlalchemy.orm import Session
from ..schema import book
from ..models import models
from typing import List




router = APIRouter(
    tags = ['Create Books']
)

@router.get('/', status_code = status.HTTP_201_CREATED)
def root():
    return {"message":"wellcome to library api please type /docs for swager"}


@router.post('/add_book', status_code = status.HTTP_201_CREATED)
def add_book(add:book.CreateBook, db:Session=Depends(get_db)):
    
    add_new = models.book_data(**add.dict())
    db.add(add_new)
    db.commit()
    db.refresh(add_new)
    return add_new


@router.get('/get_all_books', status_code = status.HTTP_200_OK, response_model=List[book.BooksOut])
def  get_book( db:Session=Depends(get_db)):

    get_new = db.query(models.book_data).all()

    return get_new


@router.get('/get_one_book_by_id{id}', status_code = status.HTTP_200_OK, response_model=book.BooksOut)
def get_book( id: str ,db:Session=Depends(get_db)):

        get_one = db.query(models.book_data).filter(models.book_data.id==id).first()

        return get_one

@router.put('/update_book_by_id/{id}', status_code=status.HTTP_200_OK)
def put_book(id:str, db:Session=Depends(get_db)):
    pbook = db.query(models.book_data).filter(models.book_data.id == id).first()

    return pbook



@router.delete('/delete_book_by_id/{id}', status_code=status.HTTP_200_OK)
def delete_book_by_id(id: str, db: Session = Depends(get_db)):
    dbook = db.query(models.book_data).filter(models.book_data.id == id)

    pbook = dbook.first()
    # if not pbook:
         
    dbook.delete(synchronize_session=False)
    db.commit()

    return {"message":"successfully deleted"}


    


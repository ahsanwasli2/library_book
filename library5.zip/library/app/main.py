from fastapi import FastAPI 
from .database import engine
from .models import models
from .router import books


models.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(books.router)
